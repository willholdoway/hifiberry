"""The HifiBerry component."""
